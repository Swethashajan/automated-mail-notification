"""
excel_to_email.py
─────────────────────────────────────────────────────────────────────────────
REPLACES: snowflake_extract.py  (when DB is not updated / manual data entry)

HOW IT WORKS:
  1. User fills in  delay_input.xlsx  with the required columns
  2. This script reads the Excel file row by row
  3. Sends one formatted delay-alert email per row via Amazon SES
     (uses the exact same email template as the original send_delay_emails.py)

RUN:
  pip install openpyxl boto3
  python excel_to_email.py
  -- OR with a custom Excel file path --
  python excel_to_email.py --file my_data.xlsx
─────────────────────────────────────────────────────────────────────────────
"""

import argparse
import uuid
import sys
import os

import boto3
import openpyxl

# ── AWS / SES config  (same as original send_delay_emails.py) ────────────────
ROLE_ARN     = 'arn:aws:iam::169987152393:role/PL_OA-oa-eui-sreclc-app09-dglobaldaaseu-idp_common'
REGION       = 'us-east-1'
SENDER_EMAIL = 'OACommunications@mail.iqvia.com'
CC_SUPPORT   = ['BDF-HDSC-Support@iqvia.com']   # always CC'd on every alert

# ── Default Excel file name ───────────────────────────────────────────────────
DEFAULT_EXCEL = 'delay_input.xlsx'

# ── Required columns in the Excel sheet ──────────────────────────────────────
# These map 1-to-1 with what Snowflake used to return.
# The Excel column header must match EXACTLY (case-insensitive handled below).
REQUIRED_COLUMNS = [
    'CLIENT',
    'COUNTRY_NAME',
    'DATASET_COUNT',
    'DS_BNDRY_ID',
    'DS_ID',
    'DS_NAME',
    'LO_CONTACT',              # semicolon-separated email(s) e.g.  a@b.com;c@d.com
    'SCHEDULED_DLVRY_END_DATE',
    'DELIVERY_TYPE',
    'FILE_PATTERN',
]

# ── Email HTML template  (unchanged from original) ───────────────────────────
EMAIL_TEMPLATE = """
<html>
<head></head>
<body>
  <p>Hi Team,</p>

  <p>
    Kindly note that the dataset(s) mentioned below are scheduled for file delivery on
    <b>{schedule_date}</b>. However, the commencement of the process is pending due to
    the missing input file in the DaaS input location.
  </p>

  <table border="1" cellpadding="6" cellspacing="0"
         style="border-collapse:collapse; font-family:Arial,sans-serif; font-size:13px;">
    <tr style="background:#f2f2f2;">
      <th align="left">Field</th>
      <th align="left">Details</th>
    </tr>
    <tr><td><b>Client</b></td>                          <td>{client}</td></tr>
    <tr><td><b>Country</b></td>                         <td>{country}</td></tr>
    <tr><td><b>Dataset Name(s)</b></td>                 <td>{dataset_name}</td></tr>
    <tr><td><b>Total Datasets Affected</b></td>         <td>{dataset_count}</td></tr>
    <tr><td><b>Delivery Type</b></td>                   <td>{delivery_type}</td></tr>
    <tr><td><b>Source File Name / Cube Pattern</b></td> <td>{file_pattern}</td></tr>
    <tr><td><b>Source Path (Input Directory)</b></td>   <td>{source_path}</td></tr>
    <tr><td><b>Scheduled Delivery Date</b></td>         <td>{schedule_date}</td></tr>
  </table>

  <br>
  <p>
    Can you please check your end and let us know when the input file will be copied
    for HDSC DaaS processing? We have informed the Global client about the delay and
    we need to confirm the estimated file delivery date.
  </p>

  <p>
    In the future, we kindly request that you provide advance notice to
    <a href="mailto:BDF-HDSC-Support@iqvia.com">BDF-HDSC-Support@iqvia.com</a>
    in case of any deviations from the schedule on your end. This proactive
    communication will assist us in adjusting our delivery timeline and effectively
    communicating with our Global clients.
  </p>

  <p>Best regards,<br>HDSC DaaS Support Team</p>
</body>
</html>
"""

# ─────────────────────────────────────────────────────────────────────────────

def assume_role(role_arn: str, region: str):
    """Assume IAM role and return temporary SES client."""
    session = boto3.Session()
    sts     = session.client("sts", region_name=region)
    try:
        resp  = sts.assume_role(
            RoleArn         = role_arn,
            RoleSessionName = "excel-mail-session-" + str(uuid.uuid4())
        )
        creds = resp["Credentials"]
        ses   = boto3.client(
            "ses",
            region_name           = region,
            aws_access_key_id     = creds["AccessKeyId"],
            aws_secret_access_key = creds["SecretAccessKey"],
            aws_session_token     = creds["SessionToken"],
        )
        print("✔  IAM role assumed successfully.")
        return ses
    except Exception as e:
        print(f"✘  ERROR assuming IAM role: {e}")
        return None


def load_excel(path: str) -> list[dict]:
    """
    Read the Excel file.
    Returns a list of dicts — one per data row.
    Column headers are normalised to UPPER_SNAKE_CASE automatically.
    """
    if not os.path.exists(path):
        print(f"✘  Excel file not found: '{path}'")
        print(f"   Please create it using the template columns:\n   {REQUIRED_COLUMNS}")
        sys.exit(1)

    wb   = openpyxl.load_workbook(path, data_only=True)
    ws   = wb.active                          # reads the first/active sheet

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        print("✘  Excel file is empty.")
        sys.exit(1)

    # Normalise headers: strip whitespace, uppercase, spaces → underscores
    raw_headers = rows[0]
    headers     = [
        str(h).strip().upper().replace(' ', '_') if h is not None else f"COL_{i}"
        for i, h in enumerate(raw_headers)
    ]

    # Validate required columns exist
    missing = [c for c in REQUIRED_COLUMNS if c not in headers]
    if missing:
        print(f"✘  Missing column(s) in Excel: {missing}")
        print(f"   Found columns: {headers}")
        sys.exit(1)

    # Build list of row dicts
    data = []
    for row in rows[1:]:                      # skip header row
        if all(cell is None for cell in row): # skip blank rows
            continue
        data.append(dict(zip(headers, row)))

    print(f"✔  Loaded {len(data)} row(s) from '{path}'")
    return data


def safe(value, default='N/A') -> str:
    """Convert any cell value to a clean string."""
    if value is None:
        return default
    s = str(value).strip()
    return s if s else default


def parse_emails(raw: str) -> list[str]:
    """
    Accept semicolon-separated OR comma-separated email list.
    Cleans up spaces and stray quotes.
    e.g.  "alice@x.com; bob@y.com"  →  ['alice@x.com', 'bob@y.com']
    """
    if not raw or str(raw).strip() in ('N/A', ''):
        return []
    # normalise separators
    normalised = str(raw).replace(';', ',')
    return [
        e.strip().strip("'\"<>")
        for e in normalised.split(',')
        if e.strip()
    ]


def send_emails(rows: list[dict], ses_client) -> None:
    """Loop through Excel rows and send one email per row."""
    sent = failed = skipped = 0

    for idx, row in enumerate(rows, start=2):   # start=2 matches Excel row numbers
        client        = safe(row.get('CLIENT'))
        country       = safe(row.get('COUNTRY_NAME'))
        dataset_name  = safe(row.get('DS_NAME'))
        dataset_count = safe(row.get('DATASET_COUNT'))
        schedule_date = safe(row.get('SCHEDULED_DLVRY_END_DATE'))
        delivery_type = safe(row.get('DELIVERY_TYPE'))
        file_pattern  = safe(row.get('FILE_PATTERN'))
        source_path   = f"/data/input/{client}/{country}/{dataset_name}/"

        # Parse recipient list from LO_CONTACT column
        lo_raw      = safe(row.get('LO_CONTACT', ''), default='')
        recipients  = parse_emails(lo_raw)

        subject = (
            f"DaaS {client} - {country} - Source file delivery delay "
            f"[{schedule_date}]"
        )

        print(f"\n[Row {idx}] {client} | {country} | {dataset_name}")
        print(f"         Recipients  : {recipients}")
        print(f"         DelivType   : {delivery_type}")
        print(f"         FilePattern : {file_pattern}")

        if not recipients:
            print(f"  → SKIP: no valid email in LO_CONTACT column.")
            skipped += 1
            continue

        body_html = EMAIL_TEMPLATE.format(
            client        = client,
            country       = country,
            dataset_name  = dataset_name,
            dataset_count = dataset_count,
            schedule_date = schedule_date,
            delivery_type = delivery_type,
            file_pattern  = file_pattern,
            source_path   = source_path,
        )

        try:
            ses_client.send_email(
                Source      = SENDER_EMAIL,
                Destination = {
                    'ToAddresses': recipients,
                    'CcAddresses': CC_SUPPORT,
                },
                Message = {
                    'Subject': {'Data': subject},
                    'Body':    {'Html': {'Data': body_html}},
                }
            )
            print(f"  → SENT  to {', '.join(recipients)}")
            sent += 1
        except Exception as e:
            print(f"  → FAIL  for {', '.join(recipients)}: {e}")
            failed += 1

    print(f"\n{'─'*55}")
    print(f"  Summary:  {sent} sent  |  {failed} failed  |  {skipped} skipped")
    print(f"{'─'*55}")


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Send delay alert emails from an Excel file via Amazon SES."
    )
    parser.add_argument(
        '--file', '-f',
        default=DEFAULT_EXCEL,
        help=f"Path to the Excel input file (default: {DEFAULT_EXCEL})"
    )
    parser.add_argument(
        '--dry-run',
        action='store_true',
        help="Parse the Excel and print what would be sent — without actually sending."
    )
    args = parser.parse_args()

    print(f"\n{'='*55}")
    print(f"  Mail Automation — Excel Mode")
    print(f"  Input file : {args.file}")
    print(f"  Dry run    : {args.dry_run}")
    print(f"{'='*55}\n")

    # 1. Load Excel data
    rows = load_excel(args.file)

    if args.dry_run:
        print("\n[DRY RUN] Emails that WOULD be sent:\n")
        for idx, row in enumerate(rows, start=2):
            lo_raw     = safe(row.get('LO_CONTACT', ''), default='')
            recipients = parse_emails(lo_raw)
            print(f"  Row {idx}: {safe(row.get('CLIENT'))} | "
                  f"{safe(row.get('COUNTRY_NAME'))} | "
                  f"To: {recipients}")
        print("\n[DRY RUN] No emails were sent.")
        sys.exit(0)

    # 2. Assume IAM role and get SES client
    ses = assume_role(ROLE_ARN, REGION)
    if not ses:
        print("✘  Aborting — could not authenticate with AWS.")
        sys.exit(1)

    # 3. Send emails
    send_emails(rows, ses)
