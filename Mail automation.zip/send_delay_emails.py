import boto3
import csv
import uuid

# ── AWS / SES config ──────────────────────────────────────────────────────────
ROLE_ARN      = 'arn:aws:iam::169987152393:role/PL_OA-oa-eui-sreclc-app09-dglobaldaaseu-idp_common'
REGION        = 'us-east-1'
SENDER_EMAIL  = 'OACommunications@mail.iqvia.com'
CC_SUPPORT    = ['BDF-HDSC-Support@iqvia.com']   # always CC'd on every alert

# ── Email template ────────────────────────────────────────────────────────────
# NEW placeholders:  {delivery_type}  {file_pattern}  {dataset_count}
EMAIL_TEMPLATE = """
<html>
<head></head>
<body>
  <p>Hi Team,</p>

  <p>
    Kindly note that the dataset(s) mentioned below are scheduled for file delivery on
    <b>{schedule_date}</b>. However, the commencement of the process is pending due to
    the missing input file in the DaaS input location.
  </p>

  <table border="1" cellpadding="6" cellspacing="0"
         style="border-collapse:collapse; font-family:Arial,sans-serif; font-size:13px;">
    <tr style="background:#f2f2f2;">
      <th align="left">Field</th>
      <th align="left">Details</th>
    </tr>
    <tr>
      <td><b>Client</b></td>
      <td>{client}</td>
    </tr>
    <tr>
      <td><b>Country</b></td>
      <td>{country}</td>
    </tr>
    <tr>
      <td><b>Dataset Name(s)</b></td>
      <td>{dataset_name}</td>
    </tr>
    <tr>
      <td><b>Total Datasets Affected</b></td>
      <td>{dataset_count}</td>
    </tr>
    <tr>
      <td><b>Delivery Type</b></td>
      <td>{delivery_type}</td>
    </tr>
    <tr>
      <td><b>Source File Name / Cube Pattern</b></td>
      <td>{file_pattern}</td>
    </tr>
    <tr>
      <td><b>Source Path (Input Directory)</b></td>
      <td>{source_path}</td>
    </tr>
    <tr>
      <td><b>Scheduled Delivery Date</b></td>
      <td>{schedule_date}</td>
    </tr>
  </table>

  <br>
  <p>
    Can you please check your end and let us know when the input file will be copied
    for HDSC DaaS processing? We have informed the Global client about the delay and
    we need to confirm the estimated file delivery date.
  </p>

  <p>
    In the future, we kindly request that you provide advance notice to
    <a href="mailto:BDF-HDSC-Support@iqvia.com">BDF-HDSC-Support@iqvia.com</a>
    in case of any deviations from the schedule on your end. This proactive
    communication will assist us in adjusting our delivery timeline and effectively
    communicating with our Global clients.
  </p>

  <p>Best regards,<br>HDSC DaaS Support Team</p>
</body>
</html>
"""

# ─────────────────────────────────────────────────────────────────────────────

def get_session_token(role_arn: str, region: str):
    """Assume the IAM role and return temporary credentials."""
    session = boto3.Session()
    sts     = session.client("sts", region_name=region)
    try:
        response = sts.assume_role(
            RoleArn         = role_arn,
            RoleSessionName = "iqvia-session-" + str(uuid.uuid4())
        )
        creds = response["Credentials"]
        return creds["AccessKeyId"], creds["SecretAccessKey"], creds["SessionToken"]
    except Exception as e:
        print(f"ERROR assuming role: {e}")
        return None, None, None


def send_emails_from_csv(csv_path: str, ses_client):
    """Read the CSV produced by snowflake_extract.py and send one email per row."""
    sent = failed = skipped = 0

    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile, delimiter='~')

        for row in reader:
            # ── Pull every column we need ─────────────────────────────────────
            client        = row.get('CLIENT',                 'N/A')
            country       = row.get('COUNTRY_NAME',           'N/A')
            dataset_name  = row.get('DS_NAME',                'N/A')
            dataset_count = row.get('DATASET_COUNT',          'N/A')
            schedule_date = row.get('SCHEDULED_DLVRY_END_DATE','N/A')
            delivery_type = row.get('DELIVERY_TYPE',          'N/A')   # NEW
            file_pattern  = row.get('FILE_PATTERN',           'N/A')   # NEW (cube/file details)

            # Build a readable source path from available context
            source_path   = f"/data/input/{client}/{country}/{dataset_name}/"

            # ── Subject line ──────────────────────────────────────────────────
            subject = (
                f"DaaS {client} - {country} - Source file delivery delay "
                f"[{schedule_date}]"
            )

            # ── Parse recipient list (comma-separated, may have single quotes) ─
            recipients_raw  = row.get('LO_CONTACT', '')
            recipient_emails = [
                e.strip().strip("'\"")
                for e in recipients_raw.split(',')
                if e.strip()
            ]

            print(f"\n[{dataset_name}] Recipients : {recipient_emails}")
            print(f"[{dataset_name}] DelivType  : {delivery_type}")
            print(f"[{dataset_name}] FilePattern: {file_pattern}")

            if not recipient_emails:
                print(f"  → SKIP: no recipient email found.")
                skipped += 1
                continue

            # ── Build HTML body ───────────────────────────────────────────────
            body_html = EMAIL_TEMPLATE.format(
                client        = client,
                country       = country,
                dataset_name  = dataset_name,
                dataset_count = dataset_count,
                schedule_date = schedule_date,
                delivery_type = delivery_type,
                file_pattern  = file_pattern,
                source_path   = source_path,
            )

            # ── Send via SES ──────────────────────────────────────────────────
            try:
                ses_client.send_email(
                    Source      = SENDER_EMAIL,
                    Destination = {
                        'ToAddresses': recipient_emails,
                        'CcAddresses': CC_SUPPORT,      # always CC support
                    },
                    Message = {
                        'Subject': {'Data': subject},
                        'Body':    {'Html': {'Data': body_html}},
                    }
                )
                print(f"  → SENT  to {', '.join(recipient_emails)}")
                sent += 1
            except Exception as e:
                print(f"  → FAIL  for {', '.join(recipient_emails)}: {e}")
                failed += 1

    print(f"\n─── Summary: {sent} sent | {failed} failed | {skipped} skipped ───")


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    key_id, secret_key, session_token = get_session_token(ROLE_ARN, REGION)

    if not key_id:
        print("ERROR: Could not assume IAM role. Email sending aborted.")
    else:
        ses = boto3.client(
            'ses',
            region_name          = REGION,
            aws_access_key_id    = key_id,
            aws_secret_access_key= secret_key,
            aws_session_token    = session_token,
        )
        send_emails_from_csv('Local_output.csv', ses)
